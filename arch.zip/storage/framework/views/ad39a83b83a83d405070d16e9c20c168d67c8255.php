<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(url('admin/css/styel.css')); ?>">
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>

<script>
swal({
  title: "تمت العملية",
  text: "<?php echo e($errors->first()); ?>",
  icon: "warning",
  buttons: false,
  dangerMode: false,
});
</script>
<?php endif; ?>
<div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 no-padding no-margin ">

<div class="modal-content col-lg-10 col-md-10 col-sm-10 col-xs-10">
  <form class="form-resp" method="post" action="<?php echo e(url('/admin/edit/user/'.$data->id)); ?>">
    <?php echo csrf_field(); ?>

    <input type="text" name="firstName" placeholder="الاسم الاول" value="<?php echo e($data->firstName); ?>">
    <input type="text" name="lastName" placeholder="الاسم الاخر" value="<?php echo e($data->lastName); ?>">
    <input type="email" name="email" placeholder="البريد الاليكتروني"  value="<?php echo e($data->email); ?>">
    <input type="text" name="phone" placeholder="رقم الجوال"  value="<?php echo e($data->phone); ?>">
    <input type="password" name="password" placeholder="كلمه المرور"  value="<?php echo e($data->password); ?>">

    <p>الصلاحيات :</p>
    <div class="block">

      <?php if($data->type_id == 2): ?>
      <div class="radio">
             <label><input type="radio"  checked="checked"  value="2" name="type_id" style="margin-top:0px">ادمن</label>
      </div>
      <div class="radio">
        <label><input type="radio"  value="3" name="type_id" style="margin-top:0px">مشرف عام</label>
      </div>
      <div class="radio">
        <label><input type="radio"  value="4" name="type_id" style="margin-top:0px">مشرف</label>
      </div>
      <?php endif; ?>
      <?php if($data->type_id == 3): ?>
      <div class="radio">
             <label><input type="radio"  value="2" name="type_id" style="margin-top:0px">ادمن</label>
      </div>
      <div class="radio">
        <label><input type="radio" checked="checked"  value="3" name="type_id" style="margin-top:0px">مشرف عام</label>
      </div>
      <div class="radio">
        <label><input type="radio"  value="4" name="type_id" style="margin-top:0px">مشرف</label>
      </div>
      <?php endif; ?>

      <?php if($data->type_id == 4): ?>
      <div class="radio">
             <label><input type="radio"  value="2" name="type_id" style="margin-top:0px">ادمن</label>
      </div>
      <div class="radio">
        <label><input type="radio" value="3" name="type_id" style="margin-top:0px">مشرف عام</label>
      </div>
      <div class="radio">
        <label><input type="radio" checked="checked" value="4" name="type_id" style="margin-top:0px">مشرف</label>
      </div>
      <?php endif; ?>




    </div>
    <input type="submit" class="sub-btn" value="تعديل">

  </form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jq'); ?>
<script src="<?php echo e(url('admin/js/jquery-3.1.1.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>