<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">

<table class="table table-hover">
<thead>
<tr>
<th>#</th>
<th>First Name</th>
<th>Last Name</th>
<th>Username</th>
</tr>
</thead>
<tbody>
<tr>
<th scope="row">1</th>
<td>Mark</td>
<td>Otto</td>
<td>@mdo</td>
</tr>

</tbody>
</table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.mainPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>