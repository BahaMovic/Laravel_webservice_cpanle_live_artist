<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(url('admin/css/styel.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 no-padding no-margin dashbord-toggle">
  <!-- Large modal -->
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
  <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" id="two_<?php echo e($row->id); ?>" aria-labelledby="myLargeModalLabel">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content toggle-table-top">
        <div class="det-prov">
          <img src="<?php echo e(url($row->image)); ?>" alt="#" title="#" class="img-responsive center-block">
          <div class="block">
            <P class='inline-block'>ألاسم : <?php echo e($row->username); ?> </P>
          </div>
          <div class="block">
            <P class='inline-block'>رقم الجوال :</P>
            <P class='inline-block'><?php echo e($row->phone); ?> </P>
          </div>
          <div class="block">
            <P class='inline-block'>الاسم التجارى :</P>
            <P class='inline-block'><?php echo e($row->tradeName); ?></P>
          </div>
          <div class="block">
            <P class='inline-block'>البريد الاليكترونى :</P>
            <P class='inline-block'><?php echo e($row->email); ?></P>
          </div>
          <div class="block">
            <P class='inline-block'>مكان وجود الخدمه :</P>
            <P class='inline-block'><?php echo e($row->address); ?></P>
          </div>
          <div class="block">
            <P class='inline-block'>عن مقدم الخدمه :</P>
            <P class='inline-block'><?php echo e($row->about); ?></P>
          </div>

          <br>

          <div class="owl-carousel owl-theme owl-one">
            <?php $__currentLoopData = $row->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <div class="item"><img src="<?php echo e(url($image->url)); ?>" alt="<?php echo e($image->url); ?>" title="<?php echo e($image->url); ?>" style="height:100px">
                <?php if(Auth::user()->type_id == 2 || Auth::user()->type_id == 3 ): ?>

              <a href="<?php echo e(url('/delete/image/'.$image->id)); ?>" style="padding:20px">مسح الصورة</a>
              <?php endif; ?>
              </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          </div>
          <br>
          <br>
          <div class="owl-carousel owl-theme owl-two">
              <?php $__currentLoopData = $row->videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="item">

              <video width="290" controls>herteW
                <source src="<?php echo e(url($video->url)); ?>" type="video/mp4">


              </video>
              <?php if(Auth::user()->type_id == 2 || Auth::user()->type_id == 3 ): ?>

<a href="<?php echo e(url('/delete/image/'.$image->id)); ?>">مسح الصورة</a>
  <?php endif; ?>

            </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          </div>
          <br>

        </div>
      </div>
    </div>
  </div>
  <!--	box-2		-->
    <!-- Large modal -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  <div class="top-2">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
  <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" id="one_<?php echo e($row->id); ?>" aria-labelledby="myLargeModalLabel">
    <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">

      <table class="table table-hover ">
      <thead>
        <tr>
          <th scope="col">اجمالى المدفوع</th>

          <th scope="col">اسم طالب الخدمه</th>
          <th scope="col">تاريخ الحجز</th>
          <th scope="col">تاريخ عمليه الحجز</th>
          <th scope="col">الوقت</th>
          <th scope="col">الخدمات</th>
          <th scope="col">الحالة</th>

        </tr>
      </thead>
      <tbody>
        <?php $total = 0; ?>
        <?php $__currentLoopData = $row->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <tr>
          <th scope="row"><?php echo e($ord->total); ?></th>

          <td><?php echo e($ord->user->firstName); ?> </td>
          <td><?php echo e($ord->date); ?></td>
          <td><?php echo e($ord->created_at); ?></td>
          <td><?php echo e($ord->time); ?></td>
          <td class="service-top">الخدمات
            <div class="hidden-service">
              <?php $serv = explode(";",$ord->services) ?>
              <?php for($i = 0 ; $i < sizeof($serv) ; $i++): ?>
              <p><?php echo e($serv[$i]); ?></p>

              <?php endfor; ?>
            </div>
          </td>
          <?php if($ord->old_date == 1): ?>
          <td>لم تمت الخدمة بعد</td>
          <?php endif; ?>
          <?php if($ord->old_date == 2): ?>
          <td>تم الانتهاء من الخدمة</td>
            <?php $total += $ord->total; ?>
          <?php endif; ?>
          <?php if($ord->old_date == 0): ?>
          <td>تم رفض الخدمة</td>
          <?php endif; ?>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

      </tbody>
    </table>
    <div class="text-center">
      <h2 class="inline-block"> اجمالى السعر المطلوب :</h2>
      <h2 class="inline-block"><?php echo e($total); ?></h2>
      <button>طباعه</button>
    </div>
  </div>
</div>
</div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>





  </div>



  <div class="box-content-dashbords">
    <table class="table table-hover ">
      <thead>
        <tr>
          <th scope="col">الاسم</th>
          <th scope="col">رقم الجوال</th>
          <th scope="col">الاسم التجارى</th>
          <th scope="col">التقييم</th>
          <th scope="col">خصائص</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <tr>
          <th scope="row"><?php echo e($row->username); ?></th>
          <td><?php echo e($row->phone); ?></td>
          <td><?php echo e($row->tradeName); ?></td>
          <td>
            <div class="stars">
          <?php for($i = 0 ; $i < intval($row->rate) ; $i++): ?>
            <a href=""><i class="fa fa-star"></i></a>
          <?php endfor; ?>
            <?php for($x = intval($row->rate) ; $x < 5 ; $x++): ?>
            <a href="<?php echo e(url('admin/edit/rate/'.$x.'/'.$row->id)); ?>"><i class="fa fa-star-o"></i></a>
            <?php endfor; ?>


          </div>
          </td>
          <td class="btns-prob">
            <i class="fa fa-eye" title="عرض" data-toggle="modal" data-target="#two_<?php echo e($row->id); ?>"></i>
            <i class="fa fa-paste" title="الاوردرات"  data-toggle="modal" data-target="#one_<?php echo e($row->id); ?>"></i>
            <?php if(Auth::user()->type_id == 2 || Auth::user()->type_id == 3 ): ?>
            <?php if($row->active == 1): ?>
          <a href="<?php echo e(url('/stop/provider/'.$row->id)); ?>"><i class="fa fa-pause" title="ايقاف مؤقت"></i></a>
          <?php endif; ?>
          <?php if($row->active == 0): ?>
          <a href="<?php echo e(url('/stop/provider/'.$row->id)); ?>"><i class="fa fa-play" title="تشغيل"></i></a>

          <?php endif; ?>
          <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

      </tbody>
    </table>



  </div>
</div>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('jq'); ?>
<script src="<?php echo e(url('admin/js/jquery-3.1.1.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>