<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <?php echo e(Form::open( [ 'url' => 'admin/add/advimages', 'method' => 'post', 'files' => true ,'style'=>"padding: 20px; margin: 10px"] )); ?>

<?php echo csrf_field(); ?>


    <div class="form-group col-lg-4" style="float:right">
      <label for="usr">صورة الاعلانات</label>
      <input type="file" class="form-control" id="usr" name="url">
    </div>
    <button type="submit" class="btn btn-default">اضافة</button>

  <?php echo e(Form::close()); ?>


  <div class="row" style="margin:0px 0px 0px 100px">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
      <div class="col-xs-6 col-md-3 ">
        <a class="thumbnail">
          <img src="<?php echo e(url($image->url)); ?>" alt="...">
        </a>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.mainPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>