<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="col-lg-12" >
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<div class="row col-lg-4 pull-right">
  <div class="">
    <div class="thumbnail">
      <img src="<?php echo e(url($row->url)); ?>" style="height:200px">
      <div class="caption">
        <h3><?php echo e($row->provider->fullName); ?></h3>
        <p>اسم المستخدم | <?php echo e($row->provider->username); ?></p>
        <p><a href="<?php echo e(url('admin/delete/images/'.$row->id)); ?>" onclick="return  confirm('؟هل تريد مسح هذه الصورة ')" class="btn btn-primary" role="button">مسح</a>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.mainPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>