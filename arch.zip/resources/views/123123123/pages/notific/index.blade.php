@extends('admin.layouts.mainPage')

@section('header')

@endsection
@section('content')
<div class="container">

<table class="table table-hover">
<thead>
<tr>
<th>#</th>
<th></th>
<th>Last Name</th>
<th>Username</th>
</tr>
</thead>
<tbody>
<tr>
<th scope="row">1</th>
<td>Mark</td>
<td>Otto</td>
<td>@mdo</td>
</tr>

</tbody>
</table>
</div>

@endsection
