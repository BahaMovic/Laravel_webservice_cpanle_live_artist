<?php $__env->startSection('content'); ?>
<div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 no-padding no-margin dashbord-toggle">
			<div class="box-content-dashbords">
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 par-box-content ">
					<div class="box-content-pro">
						<p><?php echo e($provider); ?> مقدمين الخدمه</p>
					</div>
					<div class="box-content-pro-a">
						<a href="prov.html">اعرض المزيد</a>
					</div>

				</div>
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 par-box-content ">
					<div class="box-content-pro">
						<p><?php echo e($users); ?> طالبين الخدمه</p>
					</div>
					<div class="box-content-pro-a">
						<a href="askpr.html">اعرض المزيد</a>
					</div>

				</div>
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 par-box-content ">
					<div class="box-content-pro">
						<p><?php echo e($supervisor); ?> المشرفيين</p>
					</div>
					<div class="box-content-pro-a">
						<a href="resp.html">اعرض المزيد</a>
					</div>

				</div>


			</div>
		</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>