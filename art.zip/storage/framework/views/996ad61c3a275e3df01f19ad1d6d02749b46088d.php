<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">

<table class="table table-hover" style="float:right ; width:94%">
<thead>
<tr>
<th>الرقم</th>
<th style="text-align:right">الاسم الاول</th>
<th style="text-align:right">الاسم الاخير</th>
<th style="text-align:right">البريد الالكتروني</th>
<th style="text-align:right">رقم الجوال</th>
<th style="text-align:right">الصلاحيات</th>
<th style="text-align:right">التعديل</th>



</tr>
</thead>
<tbody>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<th scope="row"><?php echo e($row->id); ?></th>
<td><?php echo e($row->firstName); ?></td>
<td><?php echo e($row->lastName); ?></td>
<td><?php echo e($row->email); ?></td>
<td><?php echo e($row->phone); ?></td>
<td><?php echo e($row->type_id); ?></td>
<td><a href="<?php echo e(url('/api/delete/user/'.$row->id)); ?>">مسح</a></td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</tbody>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.mainPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>