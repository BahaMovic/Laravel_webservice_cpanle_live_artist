<?php $__env->startSection('content'); ?>
<div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 no-padding no-margin dashbord-toggle">
  <!-- Large modal -->
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
  <div class="modal fade bs-example-modal-lg" id="one_<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content toggle-table-top">
        <table class="table table-hover">
          <thead>
            <tr>
              <th scope="col">اسم مقدم الخدمه</th>
              <th scope="col">التاريخ</th>
              <th scope="col">الوقت</th>
              <th scope="col">تاريخ الحجز</th>

              <th scope="col">الخدمات</th>
            </tr>
          </thead>
          <tbody>
            <?php $total = 0; ?>
            <?php $__currentLoopData = $row->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
              <td><?php echo e($ord->provider->firstName); ?> </td>
              <td><?php echo e($ord->date); ?></td>
              <td><?php echo e($ord->time); ?> </td>
              <td><?php echo e($ord->created_at); ?></td>

              <td class="service-top">الخدمات
                <div class="hidden-service">
                  <?php $serv = explode(";",$ord->services) ?>
                  <?php for($i = 0 ; $i < sizeof($serv) ; $i++): ?>
                  <p><?php echo e($serv[$i]); ?></p>

                  <?php endfor; ?>
                </div>
              </td>
            </tr>
              <?php $total += $ord->total; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


          </tbody>
        </table>
        <div class="text-center top-2">
          <h2 class="inline-block"> اجمالى السعر المطلوب :</h2>
          <h2 class="inline-block"><?php echo e($total); ?></h2>
          <button>طباعه</button>
        </div>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  <div class="box-content-dashbords">
    <table class="table table-hover ">
      <thead>
        <tr>
          <th scope="col">الاسم </th>
          <th scope="col">البريد الاليكترونى</th>
          <th scope="col">رقم الجوال</th>
          <th scope="col">العنوان</th>
          <th scope="col">خصائص</th>
        </tr>
      </thead>
      <tbody>
        <tr>
<!--							   والاوردرات فى جدول والاوردرات والخدمات بنفس الطريقه-->
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <th scope="row"><?php echo e($row->firstName); ?></th>
          <td><?php echo e($row->email); ?></td>
          <td><?php echo e($row->phone); ?></td>
          <td><?php echo e($row->address); ?></td>
          <td class="btns-prob">
            <i class="fa fa-paste" title="الاوردرات"  data-toggle="modal" data-target="#one_<?php echo e($row->id); ?>"></i>
            <a href="<?php echo e(url('/stop/user/'.$row->id)); ?>"><i class="fa fa-pause" title="ايقاف مؤقت"></i></a>
              <a href="<?php echo e(url('/delete/user/'.$row->id)); ?>"><i class="fa fa-trash" title="حذف"></i></a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

      </tbody>
    </table>



  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>