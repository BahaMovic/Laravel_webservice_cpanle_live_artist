<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 no-padding no-margin dashbord-toggle">
  <div class="box-content-dashbords">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ms): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <div class="col-lg-12">
      <?php if($ms->user_id == Auth::user()->id): ?>
      <div class="right chat-box">
        <h4><?php echo e($ms->message); ?></h4>
        <p><?php echo e($ms->created_at); ?></p>
      </div>
      <?php else: ?>
      <div class="left chat-box">
        <h4><?php echo e($ms->message); ?></h4>
        <p><?php echo e($ms->created_at); ?></p>
					</div>
      <?php endif; ?>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

    <div class="sent-box">
    <form action="<?php echo e(url('admin/messageadmin/'.$id)); ?>" method="post">
      <input type="text" name="message" placeholder="الرساله">
      <button type="submit"><i class="fa fa-paper-plane"></i></button>
    </form>
    </div>

  </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('jq'); ?>
<script src="<?php echo e(url('admin/js/jquery-3.1.1.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>