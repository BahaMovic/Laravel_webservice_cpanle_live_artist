<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row" style="width:90%">
    <form>
      <div class="form-group col-lg-4">
        <label for="usr">المقدم</label>
        <select class="form-control" id="sel1">
          <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <option value="<?php echo e($row->id); ?>"><?php echo e($row->fullName); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </select>
      </div>
      <div class="form-group col-lg-4">
        <label for="usr">الوقت الي </label>
        <input type="date" class="form-control" id="usr">
      </div>
      <div class="form-group col-lg-4">
        <label for="usr">الوقت من</label>
        <input type="date" class="form-control" id="usr">
      </div>


    </form>
  </div>
</div>

<table class="table table-hover" style="float:right ; width:94%">
<thead>
<tr>
<th>الرقم</th>
<th style="text-align:right">السعر الاجمالي</th>
<th style="text-align:right">الحالة</th>
<th style="text-align:right">التاريخ</th>
<th style="text-align:right">الوقت</th>

<th style="text-align:right">العنوان</th>
<th style="text-align:right">اسم مقدم الخدمة</th>
<th style="text-align:right">اسم طالب الخدمة</th>
<th style="text-align:right"> الخدمات</th>
<th style="text-align:right">مسح</th>


</tr>
</thead>
<tbody>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<th scope="row"><?php echo e($row->id); ?></th>
<td><?php echo e($row->total); ?></td>
<td><?php echo e($row->active); ?></td>
<td><?php echo e($row->date); ?></td>
<td><?php echo e($row->time); ?></td>
<td><?php echo e($row->address); ?></td>
<td><?php echo e($row->provider->fullName); ?></td>
<td><?php echo e($row->user->fullName); ?></td>
<td><?php echo e($row->services); ?></td>
<td><a href="<?php echo e(url('/api/delete/order/'.$row->id)); ?>">مسح</a></td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</tbody>
</table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.mainPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>