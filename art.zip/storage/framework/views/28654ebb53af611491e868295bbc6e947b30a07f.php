<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(url('admin/css/styel.css')); ?>">
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->type_id == 2): ?>
<div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 no-padding no-margin dashbord-toggle">
  <div class="box-content-dashbords input">
  <form action="<?php echo e(url('discount/code')); ?>" method="post">
    <input type="text" name="code" id="code" value="" readonly>
    <input type="text" name="from"  placeholder="من">
    <input type="text" name="to" placeholder="الى">
    <input type="number" name="disc" placeholder="نسبة الخصم"> %
    <button class="block btn" type="button" id="btnCode">كود جديد</button>
    <button class="btn" type="submit">أضافه</button>

  </form>

    <table class="table table-hover ">
      <thead>
        <tr>
          <th scope="col">الكود</th>
          <th scope="col">أسم المستخدم</th>
          <th scope="col">الخصم</th>
          <th scope="col">التاريخ</th>
          <th scope="col">خصائص</th>
        </tr>
      </thead>
      <tbody>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <tr>

          <th scope="row"><?php echo e($code->code); ?></th>
          <td><?php echo e($code->user->firstName); ?></td>
          <td><?php echo e($code->discount); ?>-%</td>
          <td><?php echo e($code->created_at); ?></td>
          <td class="btns-prob">

            <a href="<?php echo e(url('delete/descount/'.$code->id)); ?>"><i class="fa fa-trash" title="حذف"></i></a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

      </tbody>
    </table>



  </div>
</div>

<?php else: ?>
<div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 no-padding no-margin dashbord-toggle">

<script>
swal({
  title: "تحذير",
  text: "لا يوجد لديك صلاحية لروئية هذه الصفحة",
  icon: "warning",
  buttons: true,
  dangerMode: true,
});
</script>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jq'); ?>
<script src="<?php echo e(url('admin/js/jquery-3.1.1.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>