<?php $__env->startSection('header'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">

<table class="table table-hover" style="float:right ; width:94%">
<thead>
<tr>
<th>الرقم</th>
<th style="text-align:right">الاسم الاول</th>
<th style="text-align:right">الاسم الاخير</th>
<th style="text-align:right">الاييمل</th>
<th style="text-align:right">رقم الجوال</th>

<th style="text-align:right">التعديل</th>
<th style="text-align:right">الطلبات</th>


</tr>
</thead>
<tbody>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<tr>
<th scope="row"><?php echo e($row->id); ?></th>
<td><?php echo e($row->firstName); ?></td>
<td><?php echo e($row->lastName); ?></td>
<td><?php echo e($row->email); ?></td>
<td><?php echo e($row->phone); ?></td>

<td><a href="<?php echo e(url('/api/delete/user/'.$row->id)); ?>">مسح</a> | <a href="<?php echo e(url('/api/delay/user/'.$row->id)); ?>">ايقاف مؤقت</a></td>
<td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal<?php echo e($row->id); ?>" data-whatever="@mdo">طلبان المستخدم</button></td>
</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</tbody>
</table>
</div>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<div class="modal fade" id="exampleModal<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content" style="width:1000px; margin-right:-200px">
      <table class="table table-hover" style="float:right">
      <thead>
      <tr>
      <th style="text-align:right">الرقم</th>
      <th style="text-align:right"> اجمالي السعر</th>
      <th style="text-align:right">الحالة </th>
      <th style="text-align:right">اسم مقدم الخدمة</th>
      <th style="text-align:right">تاريخ الحجز</th>
      <th style="text-align:right">الوقت</th>
      <th style="text-align:right">العنوان</th>
      <th style="text-align:right">الخدمات</th>
      <th style="text-align:right">تاريخ عملية الحجز</th>
      <th>
      </tr>
      </thead>
      <tbody>

          <?php $__currentLoopData = $row->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <tr>
        <th scope="row"><?php echo e($list->id); ?></th>
        <td><?php echo e($list->total); ?></td>
        <td><?php echo e($list->active); ?></td>
        <td><?php echo e($list->provider->fullName); ?></td>
        <td><?php echo e($list->date); ?></td>
        <td><?php echo e($list->time); ?></td>
        <td><?php echo e($list->address); ?></td>
        <td><?php echo e($list->services); ?></td>
        <td><?php echo e($list->created_at); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      </tbody>
      </table>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">اغلاق</button>

      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.mainPage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>