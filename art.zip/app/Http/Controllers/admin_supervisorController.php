<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
class admin_supervisorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $data = User::where('type_id','>',1)->get();
        return view('admin.pages.supervisor',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        User::create([
          'firstName'=>$request['firstName'],
          'lastName'=>$request['lastName'],
          'fullName'=>$request['firstName']." ".$request['lastName'],
          'email'=>$request['email'],
          'phone'=>$request['phone'],
          'type_id'=>$request['type_id'],
          'active'=>'1',
          'password'=>$request['password']
        ]);
        return redirect('admin/supervisor');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }
    public function stop($id)
    {
      $data = User::where('id','=',$id)->get()->last();
      if($data->active == 0)
      {User::where('id','=',$id)->update(['active'=>'1']);}
      else {
        User::where('id','=',$id)->update(['active'=>'0']);
      }

      return redirect('admin/supervisor');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        User::where('id','=',$id)->delete();
        return redirect('admin/supervisor');
    }
}
